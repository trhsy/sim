package com.trhsy.sim.common.core.entity;

import com.trhsy.sim.ModSim;
import com.trhsy.sim.common.core.entity.ai.EntityAIWanderSUK;
import com.trhsy.sim.client.gui.folk.GuiEntityFolk;
import com.trhsy.sim.client.gui.folk.GuiMerchant;
import com.trhsy.sim.common.core.entity.enums.GotoMethod;
import com.trhsy.sim.common.jobs.JobFisherman;
import com.trhsy.sim.common.jobs.Stage;
import com.trhsy.sim.common.jobs.Vocation;
import com.trhsy.sim.common.loader.ConfigLoader;
import com.trhsy.sim.common.loader.ItemLoader;
import com.trhsy.sim.common.loader.ModSimReloaded;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.*;
import net.minecraft.entity.INpc;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.*;

/**
 * @ClassName EntityFolk
 * @Description todo 实体只是为了展示，实体数据实际上完成了工作，这样做不需要区块加载，因此玩家可以在几英里之外完成工作。不确定是否需要INpc，也可以使用EntityAgeable来重写？
 * @Author Tian
 * @Date 2022/5/2120:40
 **/
public class EntityFolk extends EntityCreature implements INpc {
    //参考实际的NPC代码/属性/逻辑等
    public FolkData theData;
    //用于杀死繁殖的npc，我们将繁殖它们
    private long ghostTimer = -1L;
    //问候/打招呼计时器
    private long greetTimer = 0L;
    //最后一次受伤
    private long lastHurt = 0L;
    //日历
    private Calendar cal = new GregorianCalendar();
    //找到路了吗
    public boolean gotPath;


    public EntityFolk(World world) {
        super(world);
        try {
            //避开水
            ((PathNavigateGround) this.func_70661_as()).func_179690_a(true);
            //会进门
            ((PathNavigateGround) this.func_70661_as()).func_179691_c(true);
            //破门而入
            ((PathNavigateGround) this.func_70661_as()).func_179688_b(true);
            //会游泳
            ((PathNavigateGround) this.func_70661_as()).func_179693_d(true);

            //会捡起地上的东西
            this.func_98053_h(true);

            //闲置任务
            this.field_70714_bg.func_75776_a(1, new EntityAILookIdle(this));
            //闲逛
            this.field_70714_bg.func_75776_a(1, new EntityAIWanderSUK(this, 0.5D));
            //住进屋子
            this.field_70714_bg.func_75776_a(2, new EntityAIMoveIndoors(this));
            //限制开门
            this.field_70714_bg.func_75776_a(3, new EntityAIRestrictOpenDoor(this));
            //避免实体
            this.field_70714_bg.func_75776_a(3, new EntityAIAvoidEntity(this, EntityZombie.class, 8.0F, 0.6D, 0.6D));
            this.field_70714_bg.func_75776_a(3, new EntityAIAvoidEntity(this, EntityOcelot.class, 6.0F, 1.0D, 1.2D));
            this.field_70714_bg.func_75776_a(3, new EntityAIAvoidEntity(this, EntityPlayer.class, 16.0F, 0.8D, 1.33D));
            this.field_70714_bg.func_75776_a(3, new EntityAIAvoidEntity(this, EntityWolf.class, 6.0F, 1.0D, 1.2D));
            //游泳
            this.field_70714_bg.func_75776_a(4, new EntityAISwimming(this));
            //开门
            this.field_70714_bg.func_75776_a(9, new EntityAIOpenDoor(this, true));
            //实体AI监视最近
            this.field_70714_bg.func_75776_a(9, new EntityAIWatchClosest(this, EntityLiving.class, 8.0F));
            //实体AI监视最近2
            this.field_70714_bg.func_75776_a(10, new EntityAIWatchClosest2(this, EntityPlayer.class, 3.0F, 1));

            //闲逛
            //this.tasks.addTask(9, new EntityAIWander(this, 0.6D));

            //走向限制
//            this.tasks.addTask(5, new EntityAIMoveTowardsRestriction(this, 0.3));

            //拾取战利品
            this.func_98053_h(true);
            //启动
            if (!ModSim.proxy.ranStartup) {
                ModSimReloaded.log.info("实体人：重置npc");
                this.func_70106_y();
            }
//停用算时间是否是圣诞节
//        int dom = this.cal.get(5);
//        int moy = this.cal.get(2);
//        if (dom > 23 && dom < 27 && moy == 11) {
//            this.isXmas = true;
//        }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("初始化NPC实体出问题了:" + e.getMessage() + "行数：" + element.getLineNumber());
        }

    }

    @Override
    public void func_70636_d() {
        super.func_70636_d();
    }

    /**
     * @return java.lang.String
     * @Author fan
     * @Description //TODO 获得纹理
     * @Date 17:16 2022/5/22
     * @Param []
     **/
    @SideOnly(Side.CLIENT)
    public String getTexture() {
        String texture = "";
        try {
            if (this.theData != null) {
                //System.out.println("实体人性别："+this.theData.gender);
                if (this.theData.gender == 0) {
                    texture = "male" + this.theData.skinnumber + ".png";
                } else {
                    texture = "female" + this.theData.skinnumber + ".png";
                }
            } else {
                texture = "male0.png";
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("getTexture出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return texture;
    }

    /**
     * @return void
     * @Author fan
     * @Description //TODO 实体属性
     * @Date 15:48 2022/6/5
     * @Param []
     **/
    @Override
    protected void func_110147_ax() {
        try {
            super.func_110147_ax();
            //共享怪物属性 移动速度
            this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(1.0);
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("applyEntityAttributes出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
    }

    /**
     * @return void
     * @Author fan
     * @Description //TODO 实体数据更新
     * @Date 15:50 2022/6/5
     * @Param []
     **/
    @Override
    public void func_70071_h_() {
        try {
            //如果NPC数据信息为空
            if (this.theData == null) {
                //npc 没有死
                if (!this.field_70128_L) {
                    //定时器为初始值，定义当前时间
                    if (this.ghostTimer == -1L) {
                        this.ghostTimer = System.currentTimeMillis();
                    }
                    //重新赋值NPC数据，实体 ID 的民间数据
                    this.theData = FolkData.getFolkDataByEntityId(this.func_145782_y());
                    //如果实体人数据还是空，并且五秒钟没有回复判断为死亡
                    if (this.theData == null && System.currentTimeMillis() - this.ghostTimer > 5000L) {
                        ModSimReloaded.log.info("NPC: " + this.func_145782_y() + " - 他们的数据已经空了5秒多，所以判定为死亡");
                        //设置死亡
                        //this.onDeath(DamageSource.inWall);
                        this.func_70106_y();
                    }
                }

            } else {
                //如果实体人工作中
                if (this.theData.isWorking) {

                    float s = (float) (Math.sin((double) System.currentTimeMillis() * 0.01) / 10) + 0.1F;
                    //工作进度
                    this.field_70733_aJ = s;
                } else {
                    this.field_70733_aJ = 0.0F;
                }
                //当前时间减去打招呼的时间大于1000
                if (System.currentTimeMillis() - this.greetTimer > 1000L) {
                    //定义随机值
                    Random r = new Random();
                    //获取到玩家的距离
                    double dist = (double) this.theData.getDistanceToPlayer();

                    if (ModSimReloaded.states != null) {
                        long var10000 = System.currentTimeMillis();
                        FolkData var10001 = this.theData;
                        Long ls = var10000 - FolkData.anyFolkLastSpoke;
                        //配置NPC说英文
                        if (ConfigLoader.configFolkTalkingEnglish && ls > 5000L && (!this.theData.greetedToday & dist < 5.0 || this.theData.vocation == Vocation.BURGERSWAITER && dist < 5.0 && r.nextInt(20) == 2)) {
                            this.theData.greetedToday = true;
                            FolkData var18 = this.theData;
                            FolkData.anyFolkLastSpoke = System.currentTimeMillis();
                            int sf = r.nextInt(25) + 1;
                            String fn = ModSim.MODID + ":";
                            if (this.theData.vocation != null && this.theData.vocation == Vocation.BURGERSWAITER) {
                                sf = r.nextInt(6);
                                fn = fn + "burger";
                                switch (sf) {
                                    case 0:
                                        if (this.theData.gender == 0) {
                                            fn = fn + "ma";
                                        } else {
                                            fn = fn + "fa";
                                        }
                                        break;
                                    case 1:
                                        if (this.theData.gender == 0) {
                                            fn = fn + "mb";
                                        } else {
                                            fn = fn + "fb";
                                        }
                                        break;
                                    case 2:
                                        if (this.theData.gender == 0) {
                                            fn = fn + "mc";
                                        } else {
                                            fn = fn + "fc";
                                        }
                                        break;
                                    case 3:
                                        if (this.theData.gender == 0) {
                                            fn = fn + "md";
                                        } else {
                                            fn = fn + "fd";
                                        }
                                        break;
                                    case 4:
                                        if (this.theData.gender == 0) {
                                            fn = fn + "me";
                                        } else {
                                            fn = fn + "fe";
                                        }
                                        break;
                                    case 5:
                                        if (this.theData.gender == 0) {
                                            fn = fn + "mf";
                                        } else {
                                            fn = fn + "ff";
                                        }
                                }
                            } else if (this.theData.age >= 18) {
                                if (ModSimReloaded.isDayTime()) {
                                    if (sf == 1) {
                                        if (this.theData.gender == 0) {
                                            fn = fn + "daymone";
                                        } else {
                                            fn = fn + "dayfone";
                                        }
                                    } else if (sf == 2) {
                                        if (this.theData.gender == 0) {
                                            fn = fn + "daymtwo";
                                        } else {
                                            fn = fn + "dayftwo";
                                        }
                                    } else if (sf == 3) {
                                        if (!this.field_70170_p.func_72896_J()) {
                                            if (this.theData.gender == 0) {
                                                fn = fn + "daymthree";
                                            } else {
                                                fn = fn + "dayfthree";
                                            }
                                        } else if (this.theData.gender == 0) {
                                            fn = fn + "mwxbad";
                                        } else {
                                            fn = fn + "fwxbad";
                                        }
                                    } else if (sf == 4) {
                                        if (this.theData.gender == 0) {
                                            fn = fn + "meight";
                                        } else {
                                            fn = fn + "feight";
                                        }
                                    } else if (sf == 5) {
                                        if (this.theData.gender == 0) {
                                            fn = fn + "mnine";
                                        } else {
                                            fn = fn + "fnine";
                                        }
                                    } else if (sf == 6) {
                                        if (this.theData.gender == 0) {
                                            fn = fn + "mseven";
                                        } else {
                                            fn = fn + "fseven";
                                        }
                                    } else if (sf > 6) {
                                        if (this.theData.gender == 0) {
                                            fn = fn + "mspeak";
                                        } else {
                                            fn = fn + "fspeak";
                                        }

                                        fn = fn + Character.toString((char) (sf + 90));
                                    }
                                } else if (sf == 1) {
                                    if (this.theData.gender == 0) {
                                        fn = fn + "nightmone";
                                    } else {
                                        fn = fn + "nightfone";
                                    }
                                } else if (sf == 2) {
                                    if (this.theData.gender == 0) {
                                        fn = fn + "nightmtwo";
                                    } else {
                                        fn = fn + "nightftwo";
                                    }
                                } else if (sf == 3) {
                                    if (this.theData.gender == 0) {
                                        fn = fn + "nightmthree";
                                    } else {
                                        fn = fn + "nightfthree";
                                    }
                                } else if (sf == 4) {
                                    if (this.theData.gender == 0) {
                                        fn = fn + "meight";
                                    } else {
                                        fn = fn + "feight";
                                    }
                                } else if (sf == 5) {
                                    if (this.theData.gender == 0) {
                                        fn = fn + "mnine";
                                    } else {
                                        fn = fn + "fnine";
                                    }
                                } else if (sf == 6) {
                                    if (this.theData.gender == 0) {
                                        fn = fn + "mseven";
                                    } else {
                                        fn = fn + "fseven";
                                    }
                                }
                            } else {
                                sf = r.nextInt(3) + 1;
                                fn = fn + "cspeak";
                                fn = fn + Character.toString((char) (sf + 96));
                            }

                            if (r.nextBoolean()) {
                                try {
                                    ModSim.proxy.getClientWorld().func_72980_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, fn, 1, 1, false);
                                } catch (Exception e) {
                                }
                            }
                        }
                    }

                    if (this.theData.levelFood < 0) {
                        this.func_70645_a(DamageSource.field_76366_f);
                    }

                    this.greetTimer = System.currentTimeMillis();
                }
            }

            List list1 = this.field_70170_p.func_72839_b(this, new AxisAlignedBB(this.field_70165_t, this.field_70163_u, this.field_70161_v, this.field_70165_t + 1.0, this.field_70163_u + 1.0, this.field_70161_v + 1.0).func_72314_b(2.0, 4.0, 2.0));
            if (!list1.isEmpty()) {
                for (Object entitys : list1) {
                    Entity entity = (Entity) entitys;
                    if (entity instanceof EntityItem) {
                        EntityItem entityitem = (EntityItem) entity;
                        ItemStack is = entityitem.func_92059_d();
                        Item item = is.func_77973_b();
                        if (item != null) {
                            String itemName = item.getRegistryName();
                            if (itemName.contains("mutton") || itemName.contains("rabbit") || itemName.contains("pie") || itemName.contains("carrot") || itemName.contains("potato") || itemName.contains("carrot") || itemName.contains("eye") || itemName.contains("flesh") || itemName.contains("chicken") || itemName.contains("beef") || itemName.contains("melon") || itemName.contains("cookie") || itemName.contains("fish") || itemName.contains("bread") || itemName.contains("apple") || itemName.contains("burger") || itemName.contains("fries") || itemName.contains("cheese")) {
                                System.out.println(itemName);
                                ItemFood food = (ItemFood) item;
                                if (this.theData.levelFood < 10 && food != null) {
                                    this.field_70170_p.func_72956_a(this, "random.burp", 1, 1);
                                    entityitem.func_70106_y();
                                    ++this.theData.levelFood;
                                }
                            }
                        }

                    } else if (entity instanceof EntityFolk && (int) this.field_70165_t == (int) entity.field_70165_t && (int) this.field_70161_v == (int) entity.field_70161_v) {
                        if (this.theData != null) {
                            this.field_70159_w += 0.10000000149011612D;
                            this.theData.stayPut = false;
                        }
                    }
                }
            }
            super.func_70071_h_();
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("EntityFolk-onUpdate出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
            e.printStackTrace();
        }

    }

    /**
     * @return void
     * @Author fan
     * @Description //TODO 移动实体开始传送
     * @Date 15:59 2022/6/5
     * @Param [d, d1, d2]
     **/
    @Override
    public void func_70091_d(double x, double y, double z) {
        try {
            if (this.theData != null) {
                double dist = 0;
                if (this.theData.destination != null && this.theData.beamingTo == null) {
                    try {
                        dist = this.func_70011_f(this.theData.destination.field_72450_a, this.theData.destination.field_72448_b, this.theData.destination.field_72449_c);
                    } catch (Exception e) {
                        ModSimReloaded.log.warn("人们 theData.destination 中的目标为空 moveEntity()");
                        return;
                    }

                    if (dist <= 2.0) {
                        this.theData.updateLocationFromEntity();
                        this.field_70159_w = 0;
                        this.field_70179_y = 0;
                        this.theData.stayPut = true;
                        this.theData.destination = null;
                        this.func_70661_as().func_75499_g();
                        this.gotPath = false;
                        if (this.theData.actionArrival != null) {
                            this.theData.action = this.theData.actionArrival;
                            this.theData.actionArrival = null;
                        }
                    } else {
                        if (!this.gotPath) {
                            Boolean flag = this.func_70661_as().func_75492_a(this.theData.destination.field_72450_a, this.theData.destination.field_72448_b, this.theData.destination.field_72449_c, 0.3D);
                            this.gotPath = flag;
                            if (flag == false) {
                                V3 v = new V3(this.theData.destination.field_72450_a + 0.5, this.theData.destination.field_72448_b, this.theData.destination.field_72449_c + 0.5);
                                this.theData.destination = v;
                                PathEntity path = this.func_70661_as().func_75488_a(v.field_72450_a, v.field_72448_b, v.field_72449_c);
                                if (path != null) {
                                    ModSimReloaded.log.info("实体人:[ " + this.theData.name + " ]即走过去☞x:" + v.field_72450_a + ",y:" + v.field_72448_b + ",z:" + v.field_72449_c);
                                    this.func_70661_as().func_75484_a(path, 0.3D);
                                    this.gotPath = true;
                                }
                            }
                        }
                    }

                    boolean donttimeout = false;
                    if (this.theData.destination != null) {
                        donttimeout = this.theData.destination.doNotTimeout;
                    }
                    if (this.theData.timeStartedGotoing != null && !donttimeout) {
                        if (System.currentTimeMillis() - this.theData.timeStartedGotoing > 40000L &&this.theData.beamingTo == null) {
                            this.func_70661_as().func_75499_g();
                            if (dist > 2.0) {
                                V3 v = this.theData.destination;
                                if (v != null) {
                                    ModSimReloaded.log.info("实体人: " + this.theData.name + " 即将传输至☞x:" + v.field_72450_a + ",y:" + v.field_72448_b + ",z:" + v.field_72449_c);
                                    this.theData.stayPut = true;
                                    this.theData.timeStartedGotoing = System.currentTimeMillis();
                                    this.theData.beamMeTo(v);
                                }

                            }
                        }
                    }
                }else{
                    if (x <= 0) {
                        x = this.theData.location.field_72450_a+0.5;
                    }
                    if (y <= 0) {
                        y = this.theData.location.field_72448_b+0.5;
                    }
                    if (z <= 0) {
                        z = this.theData.location.field_72449_c+0.5;
                    }
                    this.theData.destination=new V3(x,y,z);
                    super.func_70091_d(x, y, z);
                }
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("moveEntity出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
    }

    /**
     * @return net.minecraft.item.ItemStack
     * @Author fan
     * @Description //TODO 持有物品
     * @Date 16:00 2022/6/5
     * @Param []
     **/
    @Override
    public ItemStack func_70694_bm() {
        ItemStack itemStack = null;
        try {
            if (this.theData == null) {
                return null;
            } else if (this.theData.theirJob == null) {
                return null;
            } else if (this.theData.vocation == Vocation.CROPFARMER) {
                //农民
                itemStack = new ItemStack(ItemLoader.tinHoe, 1);
            } else if (this.theData.vocation == Vocation.LUMBERJACK) {
                //伐木工人
                itemStack = new ItemStack(ItemLoader.tinAxe, 1);
            } else if (this.theData.vocation == Vocation.MINER) {
                //矿工
                itemStack = new ItemStack(ItemLoader.tinPickaxe, 1);
            } else if (this.theData.vocation == Vocation.BAKER) {
                //面包师
                itemStack = new ItemStack(Items.field_151038_n, 1);
            } else if (this.theData.vocation == Vocation.SOLDIER) {
                //战士
                itemStack = new ItemStack(ItemLoader.tinSword, 1);
            } else if (this.theData.vocation == Vocation.BUILDER) {
                //建筑者
                itemStack = new ItemStack(Blocks.field_150347_e, 1);
            } else if (this.theData.vocation == Vocation.SHEPHERD) {
                //牧羊人
                itemStack = new ItemStack(Items.field_151097_aZ, 1);
            } else if (this.theData.vocation == Vocation.GROCER) {
                //杂货商
                itemStack = new ItemStack(Items.field_151127_ba, 1);
            } else if (this.theData.vocation == Vocation.COURIER) {
                //快递员
                itemStack = new ItemStack(Blocks.field_150486_ae, 1);
            } else if (this.theData.vocation == Vocation.MERCHANT) {
                //建筑商
                itemStack = new ItemStack(Blocks.field_150336_V, 1);
            } else if (this.theData.vocation == Vocation.BUTCHER) {
                //屠夫
                itemStack = new ItemStack(Items.field_151147_al, 1);
            } else if (this.theData.vocation == Vocation.CATTLEFARMER) {
                //养牛户
                itemStack = new ItemStack(ItemLoader.tinAxe, 1);
            } else if (this.theData.vocation == Vocation.PIGFARMER) {
                //养猪户
                itemStack = new ItemStack(ItemLoader.tinAxe, 1);
            } else if (this.theData.vocation == Vocation.CHICKENFARMER) {
                //养鸡户
                itemStack = new ItemStack(ItemLoader.tinAxe, 1);
            } else if (this.theData.vocation == Vocation.TERRAFORMER) {
                //地形成型机
                itemStack = new ItemStack(Items.field_151047_v, 1);
            } else if (this.theData.vocation == Vocation.GLASSMAKER) {
                //玻璃工人
                itemStack = new ItemStack(Blocks.field_150410_aZ, 1);
            } else if (this.theData.vocation == Vocation.DAIRYFARMER) {
                //牛奶农
                itemStack = new ItemStack(Items.field_151117_aB, 1);
            } else if (this.theData.vocation == Vocation.CHEESEMAKER) {
                //奶酪匠
                itemStack = new ItemStack(ItemLoader.itemCheese, 1, 0);
            } else if (this.theData.vocation == Vocation.BURGERSMANAGER) {
                //汉堡经理
                itemStack = new ItemStack(ItemLoader.itemCheeseburger, 1, 3);
            } else if (this.theData.vocation == Vocation.BURGERSFRYCOOK) {
                //后厨
                itemStack = new ItemStack(ItemLoader.tinSpade, 1);
            } else if (this.theData.vocation == Vocation.BURGERSWAITER) {
                //汉堡服务员
                itemStack = new ItemStack(ItemLoader.itemFries, 1, 2);
            } else if (this.theData.vocation == Vocation.FISHERMAN) {
                //职业渔夫
                JobFisherman jf = (JobFisherman) this.theData.theirJob;
                itemStack = jf.theStage == Stage.IDLE ? new ItemStack(Items.field_151115_aP, 1) : new ItemStack(Items.field_151112_aM, 1);
            } else {
                return null;
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("getHeldItem出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return itemStack;
    }

    /**
     * @return boolean
     * @Author fan
     * @Description //TODO 互动
     * @Date 16:02 2022/6/5
     * @Param [entityplayer]
     **/
    @Override
    @SideOnly(Side.CLIENT)
    public boolean func_70085_c(EntityPlayer entityplayer) {
        boolean falg = true;
        try {
            Minecraft mc = Minecraft.func_71410_x();
            mc.field_71462_r = null;
            GuiScreen ui = null;
            if (this.theData == null) {
                this.func_70106_y();
                falg = false;
            } else {
                if (this.theData.theirJob != null) {
                    if (this.theData.vocation == Vocation.MERCHANT && ModSimReloaded.isDayTime()) {
                        ui = new GuiMerchant();
                    } else {
                        ui = new GuiEntityFolk(this.theData, entityplayer);
                    }
                } else {
                    ui = new GuiEntityFolk(this.theData, entityplayer);
                }

                mc.func_147108_a(ui);
                if (this.theData.age < 18) {
                    this.field_70170_p.func_72980_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, ModSim.MODID + ":helloc", 1, 1, false);
                } else if (this.theData.gender == 0) {
                    this.field_70170_p.func_72980_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, ModSim.MODID + ":hellom", 1, 1, false);
                } else {
                    this.field_70170_p.func_72980_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, ModSim.MODID + ":hellof", 1, 1, false);
                }

                falg = true;
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("interact出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return falg;
    }

    /**
     * @return void
     * @Author fan
     * @Description //TODO 死亡
     * @Date 16:03 2022/6/5
     * @Param [d]
     **/
    @Override
    public void func_70645_a(DamageSource d) {
        try {
            this.theData.eventDied(d);
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("onDeath出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
    }

    /**
     * @return boolean
     * @Author fan
     * @Description //TODO 可以推
     * @Date 16:03 2022/6/5
     * @Param []
     **/
    @Override
    public boolean func_70104_M() {
        return true;
    }

    /**
     * @return java.lang.String
     * @Author fan
     * @Description //TODO 受到 伤害声音
     * @Date 16:04 2022/6/5
     * @Param []
     **/
    @Override
    protected String func_70621_aR() {
        String hurtSound = null;
        try {
            if (!this.func_70027_ad()) {
                this.func_70691_i(10.0F);
                if (this.theData != null) {
                    if (this.theData.stayPut) {
                        this.theData.stayPut = false;
                    }
                    BlockPos blockPos1 = new BlockPos(this.field_70165_t + 1, this.field_70163_u, this.field_70161_v);
                    BlockPos blockPos2 = new BlockPos(this.field_70165_t - 1, this.field_70163_u, this.field_70161_v);
                    BlockPos blockPos3 = new BlockPos(this.field_70165_t, this.field_70163_u, this.field_70161_v + 1);
                    BlockPos blockPos4 = new BlockPos(this.field_70165_t + 1, this.field_70163_u, this.field_70161_v - 1);
                    Block idx = this.field_70170_p.func_180495_p(blockPos1).func_177230_c();
                    Block idX2 = this.field_70170_p.func_180495_p(blockPos2).func_177230_c();
                    Block idz = this.field_70170_p.func_180495_p(blockPos3).func_177230_c();
                    Block idZ2 = this.field_70170_p.func_180495_p(blockPos4).func_177230_c();
                    if (this.theData.location != null) {
                        this.field_70181_x = this.theData.location.field_72448_b + 1;
                        this.field_70159_w = this.theData.location.field_72450_a;
                        this.field_70179_y = this.theData.location.field_72449_c;
                    }

                    if (idx != null && idx == Blocks.field_150350_a) {
                        this.field_70159_w = this.theData.location.field_72450_a + 1;
                    } else if (idX2 != null && idX2 == Blocks.field_150350_a) {
                        this.field_70159_w = this.theData.location.field_72450_a - 1;
                    } else if (idz != null && idz == Blocks.field_150350_a) {
                        this.field_70179_y = this.theData.location.field_72449_c + 1;
                    } else if (idZ2 != null && idZ2 == Blocks.field_150350_a) {
                        this.field_70179_y = this.theData.location.field_72449_c - 1;
                    }
                    //受伤要跑出受伤范围
                    this.theData.gotoXYZ(new V3(field_70159_w, field_70181_x, field_70179_y, 0), null);
                }

                if (this.theData == null) {
                    hurtSound = null;
                } else if (ConfigLoader.configFolkTalking) {
                    if (System.currentTimeMillis() - this.lastHurt > 10000L) {
                        this.lastHurt = System.currentTimeMillis();
                        hurtSound = this.theData.gender == 0 ? ModSim.MODID + ":OuchM" : ModSim.MODID + ":OuchF";
                    } else {
                        hurtSound = null;
                    }
                } else {
                    hurtSound = null;
                }
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("getHurtSound出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return hurtSound;
    }

    @Override
    public int func_70627_aG() {
        Random r = new Random();
        return 1000 + r.nextInt(1000);
    }

    //@Override
    //public boolean isAIEnabled() {
    //    return true;
    //}

    @Override
    public int func_70641_bl() {
        return 200;
    }

    @Override
    public boolean func_70692_ba() {
        return true;
    }

    //@Override
    //public AxisAlignedBB getCollisionBox(Entity par1Entity) {
    //    return par1Entity.getCollisionBox(par1Entity);
    //}

    //@Override
    //public AxisAlignedBB getBoundingBox() {
    //    return this.boundingBox;
    //}

    @Override
    public boolean func_70067_L() {
        return true;
    }

    public void onPlayerLogin(EntityPlayer player) {
    }

    public void onPlayerLogout(EntityPlayer player) {
    }

    public void onPlayerRespawn(EntityPlayer player) {
    }


}

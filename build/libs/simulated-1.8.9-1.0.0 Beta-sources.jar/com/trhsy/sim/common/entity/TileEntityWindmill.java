package com.trhsy.sim.common.entity;

import net.minecraft.tileentity.TileEntity;

/**
 * @ClassName TileEntityWindmill
 * @Description todo 风车实体
 * @Author Tian
 * @Date 2022/5/1121:39
 **/
public class TileEntityWindmill extends TileEntity {
}

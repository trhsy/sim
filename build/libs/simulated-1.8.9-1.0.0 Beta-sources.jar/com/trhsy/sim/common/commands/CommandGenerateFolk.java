package com.trhsy.sim.common.commands;

import com.trhsy.sim.common.entity.FolkData;
import com.trhsy.sim.common.loader.ModSimReloaded;
import com.trhsy.sim.packets.PacketHandler;
import com.trhsy.sim.packets.server.GenerateFolkPacket;
import net.minecraft.client.resources.I18n;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class CommandGenerateFolk implements ICommand {

    private final List aliases;

    public CommandGenerateFolk() {
        aliases = new ArrayList();
        aliases.add("generate NPC");
        aliases.add("generate SIM");
    }

    @Override
    public int compareTo(ICommand arg0) {
        return 0;
    }

    @Override
    public String func_71517_b() {
        return "generate NPC";
    }

    @Override
    public String func_71518_a(ICommandSender p_71518_1_) {
        return "generate NPC <name>";
    }

    @Override
    public List func_71514_a() {
        return this.aliases;
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] argString) {
        try {
            if (argString.length == 0) {
                //FolkData.forceGenerateNewFolk(sender.getEntityWorld());
                PacketHandler.net.sendToServer(new GenerateFolkPacket(sender.func_130014_f_(), true));
            } else if (argString.length == 1) {
                FolkData.forceGenerateNewFolk(sender.func_130014_f_(), argString[0]);
            } else if (argString.length == 2) {
                FolkData.forceGenerateNewFolk(sender.func_130014_f_(), argString[0] + " " + argString[1]);
            } else {
                ModSimReloaded.sendChat(I18n.func_135052_a("container.sim.commands2"));
            }
        } catch (Exception e) {
            ModSimReloaded.log.error("出错了：" + e.getMessage());
        }

    }

    @Override
    public boolean func_71519_b(ICommandSender p_71519_1_) {
        return true;
    }

    @Override
    public List<String> func_180525_a(ICommandSender p_71516_1_, String[] args, BlockPos blockPos) {
        if (args.length == 1) {
            String[] names = MinecraftServer.func_71276_C().func_71213_z();
            return CommandBase.func_71530_a(args, names);
        }
        return null;
    }

    @Override
    public boolean func_82358_a(String[] p_82358_1_, int p_82358_2_) {
        return false;
    }

}
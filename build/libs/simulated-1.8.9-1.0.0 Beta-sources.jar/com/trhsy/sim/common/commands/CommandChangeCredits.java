package com.trhsy.sim.common.commands;

import com.trhsy.sim.common.loader.ModSimReloaded;
import net.minecraft.client.resources.I18n;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.BlockPos;

import java.util.ArrayList;
import java.util.List;

/**
 * 命令更改金钱
 */
public class CommandChangeCredits implements ICommand {

    private final List aliases;

    /**
     * 命令更改金币
     */
    public CommandChangeCredits() {
        aliases = new ArrayList();
        aliases.add("credits");
    }

    @Override
    public String func_71517_b() {
        return "credits";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "change credits <amount>";
    }

    @Override
    public List func_71514_a() {
        return this.aliases;
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] argString) {
        try {
        if (argString.length == 0) {
            //无效的参数，应该是：/credits <amount>
            ModSimReloaded.sendChat(I18n.func_135052_a("container.sim.commands1"));
            return;
        }
            if (argString.length < 2) {
                ModSimReloaded.states.credits = Float.parseFloat(argString[0]);
                ModSimReloaded.states.saveStates();
            } else {
                //无效的参数，应该是：/credits <amount>
                ModSimReloaded.sendChat(I18n.func_135052_a("container.sim.commands1"));
                return;
            }
        } catch (Exception e) {
            //金额必须是数字！
            ModSimReloaded.sendChat(I18n.func_135052_a("container.sim.commands2"));
            //ModSimReloaded.log.error("初始化对齐梁出错了：" + e.getMessage());
            return;
        }
    }

    @Override
    public boolean func_71519_b(ICommandSender p_71519_1_) {
        return true;
    }

    @Override
    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        if (args.length == 1) {
            String[] names = MinecraftServer.func_71276_C().func_71213_z();
            return CommandBase.func_71530_a(args, names);
        }
        return null;
    }

    @Override
    public boolean func_82358_a(String[] p_82358_1_, int p_82358_2_) {
        return false;
    }

    @Override
    public int compareTo(ICommand o) {
        return 0;
    }
}

package com.trhsy.sim.common.loader;

import com.trhsy.sim.client.ClientTickHandler;
import com.trhsy.sim.common.entity.CommonTickHandler;
import com.trhsy.sim.common.entity.FolkData;
import com.trhsy.sim.common.event.PlayerRightClickGrassBlockEvent;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.fluids.*;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * @ClassName EventLoader
 * @Description todo 事件交互
 * @Author Tian
 * @Date 2022/5/921:38
 **/
public class EventLoader {
    /**
     * 自定义的事件在这里被注册
     **/
    public static final EventBus EVENT_BUS = new EventBus();

    public EventLoader() {
        try {
            MinecraftForge.EVENT_BUS.register(this);
            MinecraftForge.EVENT_BUS.register(new CommonTickHandler());
            MinecraftForge.EVENT_BUS.register(new ClientTickHandler());
            EventLoader.EVENT_BUS.register(this);
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("EventLoader出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }
    }

    /**
     * @return void
     * @Author fan
     * @Description //TODO 监听一下桶被盛装的事件
     * @Date 21:40 2022/5/9
     * @Param [event]
     **/
    @SubscribeEvent
    public void onFillBucket(FillBucketEvent event) {
        //System.out.println("桶被盛装的事件");
        try {
            //获取区块位置
            BlockPos blockpos = event.target.func_178782_a();
            //获取区块状态
            IBlockState blockState = event.world.func_180495_p(blockpos);
            //获取流体
            Fluid fluid = FluidRegistry.lookupFluidForBlock(blockState.func_177230_c());
            if (fluid != null && new Integer(0).equals(blockState.func_177229_b(BlockFluidBase.LEVEL))) {
                //桶容积
                FluidStack fluidStack = new FluidStack(fluid, FluidContainerRegistry.BUCKET_VOLUME);
                event.world.func_175698_g(blockpos);
                event.result = FluidContainerRegistry.fillFluidContainer(fluidStack, event.current);
                event.setResult(Event.Result.ALLOW);
            }
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("onFillBucket出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }
    }

    /**
     * @return void
     * @Author fan
     * @Description //TODO 右键草方块
     * @Date 23:47 2022/5/13
     * @Param [event]
     **/
    @SubscribeEvent
    public void onPlayerClickGrassBlock(PlayerRightClickGrassBlockEvent event) {
        try {
            if (!event.world.field_72995_K) {
//            BlockPos pos = event.pos;
//            Entity tnt = new EntityTNTPrimed(event.world, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, null);
//            event.world.spawnEntityInWorld(tnt);
                FolkData.generateNewFolk(event.world);
            }
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("onPlayerClickGrassBlock出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }

    }

    /**
     * @return void
     * @Author fan
     * @Description //TODO 热键时间
     * @Date 23:47 2022/5/13
     * @Param [event]
     **/
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        try {
            if (KeyLoader.showTime.func_151468_f()) {
                EntityPlayer player = Minecraft.func_71410_x().field_71439_g;
                World world = Minecraft.func_71410_x().field_71441_e;
                player.func_145747_a(new ChatComponentTranslation("chat.sim.time", world.func_82737_E()));
            }
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("EventLoader-onKeyInput出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }


    }

}

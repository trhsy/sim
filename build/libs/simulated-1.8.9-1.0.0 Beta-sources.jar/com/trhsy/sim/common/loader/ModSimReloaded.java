package com.trhsy.sim.common.loader;

import com.trhsy.sim.ModSim;
import com.trhsy.sim.common.core.entity.*;
import com.trhsy.sim.common.core.entity.functionality.FarmingBox;
import com.trhsy.sim.common.core.entity.functionality.MiningBox;
import com.trhsy.sim.common.gui.GuiRunMod;
import com.trhsy.sim.common.jobs.JobSoldier;
import com.trhsy.sim.common.jobs.Vocation;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 加载任务
 */
public class ModSimReloaded {
    /**
     * 日志
     **/
    public static Logger log;
    /*
    用于检测我们何时进入世界（非主菜单）以及玩家何时更改世界/地图
     */
    public static String currentSavePath = "";

    /*
    所有民众的数据（用于构建和维护 EntityFolk）
     */
    public static List<FolkData> theFolks = new CopyOnWriteArrayList();
    /*
   所有的建筑对象
    */
    public static List<Building> theBuildings = new CopyOnWriteArrayList();
    /*
    所有快递任务
     */
    public static List<CourierTask> theCourierTasks = new CopyOnWriteArrayList();
    /*
    所有快递点
     */
    public static List<V3> theCourierPoints = new CopyOnWriteArrayList();
    /*
    所有的采矿箱
     */
    public static List<MiningBox> theMiningBoxes = new CopyOnWriteArrayList();
    /*
    所有养殖箱
     */
    public static List<FarmingBox> theFarmingBoxes = new CopyOnWriteArrayList();
    /*
   所有情感关系
    */
    public static List<Relationship> theRelationships = new CopyOnWriteArrayList();
    /*
    包含他们正在玩的这个关卡的所有游戏状态和设置
     */
    public static GameStates states = new GameStates();
    /*
    银行目前正在销售的商品列表，每天早上都会更新新商品
     */
    public static List<Commodity> theCommodities = new CopyOnWriteArrayList();
    /*
    用于在update（）调用中升级作物农场
     */
    public static FarmingBox farmToUpgrade = null;
    /*
    升级作物农场计数
     */
    public static int farmToUpgradeCounter = 0;
    /*
    所有的农场升级点
     */
    private static List<V3> farmToUpgradePoints = null;
    /*
    白天
     */
    public static boolean isDay = true;
    /*
    所有的拆除
     */
    public static List<V3> demolishBlocks = new CopyOnWriteArrayList();
    /*
    拆除
     */
    public static World demolishWorld = null;
    //Gui的运行模式
    private static GuiRunMod runModui = null;

    public ModSimReloaded() {

    }

    /**
     * 重置并加载新世界
     */
    public static void resetAndLoadNewWorld() {
        try {
            if (ModSim.proxy.ranStartup) {
                ModSimReloaded.log.info("模拟城市程序已经运行");
                ModSim.proxy.ranStartup = true;
                return;
            }
            //获取有效的线程
            Side side = FMLCommonHandler.instance().getEffectiveSide();
            ModSimReloaded.log.info("重置并加载世界 " + side.toString() + " SIDE");
            //建筑对象清除
            theBuildings.clear();
            //快递点清除
            theCourierPoints.clear();
            //快递任务清除
            theCourierTasks.clear();
            //采矿箱清除
            theMiningBoxes.clear();
            //农田箱清除
            theFarmingBoxes.clear();
            //NPC清除
            theFolks.clear();
            //情感关系清除
            theRelationships.clear();
            //读取游戏设置文件
            File f = new File(getSavesDataFolder() + "settings.sk2");
            if (!f.exists()) {
                f = new File(getSavesDataFolder() + "settings.suk");
            }
            //文件存在则读取
            if (f.exists()) {
                //重新从配置列表读取信息读取信息
                states.loadStates();
                try {
                    //设置游戏模式为读取到的模式
                    GameMode.setGameModeFromNumber(states.gameModeNumber);
                } catch (Exception e) {
                    //设置错误
                    GameMode.setGameModeFromNumber(0);
                }
            } else {
                //不存在则更新
                states = new GameStates();
                states.saveStates();
            }
            //如果游戏状态为空
            if (states == null) {
                (new File(getSavesDataFolder() + "settings.sk2")).delete();
                states = new GameStates();
                states.saveStates();
                //你的SimCity设置文件已损坏，我必须重新创建一个
                String sim_settings = I18n.func_135052_a("container.sim.sim_settings");
                sendChat(sim_settings);
            }
            //如果未运行模拟城市，弹出GUI页面
            if (states.gameModeNumber == -1) {
                if (ModSimReloaded.runModui == null) {
                    runModui = new GuiRunMod();
                    Minecraft.func_71410_x().func_147108_a(runModui);
                }
            } else {
                if (states.gameModeNumber >= 0) {

                    //欢迎来到模拟城镇,由TRHSY重制，更多资讯请关注公众号: dasha5000
                    String welcome = I18n.func_135052_a("container.sim.welcome");
                    String welcomes = I18n.func_135052_a("container.sim.welcomes");
                    sendChat(welcome + ModSim.VERSION + welcomes);
                    //清空线程池中的所有npc
                    theFolks.clear();
                    //从磁盘加载所有建筑并初始化它们
                    Building.initialiseAllBuildings();
                    //加载世界上的建筑
                    Building.loadAllBuildings();
                    //所有快递点
                    CourierTask.loadCourierTasksAndPoints();
                    //采矿箱
                    MiningBox.loadMiningBoxes();
                    //农田箱
                    FarmingBox.loadFarmingBoxes();
                    //加载npc人物
                    FolkData.loadAndSpawnFolks();
                    //npc关系
                    Relationship.loadRelationships();
                    //updateCheck();
                    //更新时间
                    isDay = isDayTime();
                    Building.checkTenants();
                    //模组已运行
                    ModSim.proxy.ranStartup = true;
                }
            }
            //模组已运行
            ModSim.proxy.ranStartup = true;
            ModSimReloaded.log.info("重载世界结束");
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("resetAndLoadNewWorld出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
    }

    /**
     * 帮助功能，向所有世界/维度的所有玩家发送聊天信息
     *
     * @param theText
     */
    public static void sendChat(String theText) {
        try {
            WorldServer[] worldServers = MinecraftServer.func_71276_C().field_71305_c;
            int length = worldServers.length;
            for (World w : MinecraftServer.func_71276_C().field_71305_c) {
                if (!w.field_72995_K) {
                    for (int k = 0; k < w.field_73010_i.size(); ++k) {
                        EntityPlayer p = (EntityPlayer) w.field_73010_i.get(k);
                        p.func_146105_b(new ChatComponentText(theText));
                    }
                }
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("sendChat出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
    }

    /**
     * 以字符串形式获取“.minecraft/saves/CURRENTWORLD/sim/”文件夹 保存数据文件夹
     *
     * @return
     */
    public static String getSavesDataFolder() {
        String ret = "";
        try {
            String worldname = MinecraftServer.func_71276_C().func_71270_I();
            String strmc = (new File(".")).getAbsolutePath();
            strmc = strmc.substring(0, strmc.length() - 1);
            File test = new File(strmc + "saves");
            if (test.exists()) {
                //客户端
                ret = (new File(strmc + File.separator + "saves" + File.separator + worldname + File.separator + "sim" + File.separator)).getAbsolutePath() + File.separator;
            } else {
                //服务器端
                strmc = strmc + worldname + File.separator + "sim" + File.separator;
                ret = (new File(strmc)).getAbsolutePath();
            }

            File f = new File(ret);
            if (!f.exists()) {
                f.mkdirs();
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("getSavesDataFolder出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return ret;
    }

    /**
     * 获取模拟城市建筑文文件夹
     *
     * @return
     */
    public static String getSimukraftFolder() {
        try {
            String strmc = (new File(".")).getAbsolutePath();
            strmc = strmc.substring(0, strmc.length() - 1);
            File checks = new File(strmc + File.separator + "mods" + File.separator + "sim");
            if (!checks.exists() && !checks.isDirectory()) {
                ModSimReloaded.log.warn("SimCity error - Mod未正确安装, ./minecraft/mods/sim/ 文件夹丢失了 - 重新创建此文件夹");
                checks.mkdir();
            }
            return (checks).getAbsolutePath();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * 判断是否白天 当世界上是白天时返回true，忽略其他世界时间
     *
     * @return
     */
    public static boolean isDayTime() {
        //if (MinecraftServer.getServer().worldServers[0].getWorldInfo().getWorldTime() % 24000 <= 11999) {
        //    return true;
        //} else {
        //    return false;
        //}
        boolean falg = false;
        try {
            falg = MinecraftServer.func_71276_C().field_71305_c[0].func_72935_r();
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("isDayTime出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return falg;

    }

    /**
     * display Money 显示金钱
     * 返回格式良好的货币值
     *
     * @param moneyin
     * @return
     */
    public static String displayMoney(float moneyin) {
        String output = null;
        try {
            DecimalFormat myFormatter = new DecimalFormat("#,##0.00");
            output = myFormatter.format((double) moneyin);
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("displayMoney出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return output;
    }

    private String getTheirId() {
        return null;
    }

    public static void dayTransitionHandler() {
        try {
            if (isDayTime() && isDay == false) {
                //日转换
                isDay = true;
                //Night to day transition
                ModSimReloaded.log.info("天亮了");
                World world = ModSim.proxy.getClientWorld();
                if (world != null) {
                    EntityPlayer p = Minecraft.func_71410_x().field_71439_g;
                    if (p != null) {
                        ModSim.proxy.getClientWorld().func_72980_b(p.field_70165_t, p.field_70163_u, p.field_70161_v, ModSim.MODID + ":rooster", 1, 1, false);
                    }
                }

                states.dayOfWeek++;
                if (states.dayOfWeek > 6) {
                    states.dayOfWeek = 0;
                    int homeless = 0;
                    for (FolkData folk1 : theFolks) {
                        if (folk1.getHome() == null) {
                            homeless++;
                        }
                    }

                    if (homeless > 1) {
                        String sim_residential = I18n.func_135052_a("container.sim.sim_residential");
                        String sim_residentials = I18n.func_135052_a("container.sim.sim_residentials");
                        sendChat(sim_residential + homeless + sim_residentials);
                    }
                }

                evolveFolks();
                if (theFolks.size() > 1) {
                    Random rand = new Random();
                    int f1 = rand.nextInt(theFolks.size());

                    int f2 = f1;
                    while (f2 == f1) {
                        f2 = rand.nextInt(theFolks.size());
                    }
                    FolkData folk1 = (FolkData) theFolks.get(f1);
                    FolkData folk2 = (FolkData) theFolks.get(f2);
                    Relationship.meddleWithRelationship(folk1, folk2);
                }
            }

            if (!isDayTime() && isDay == true) {
                isDay = false;
                //Day to Night transition
                ModSimReloaded.log.info("渡过一晚");
                if (theFolks.size() > 1) {
                    Random rand = new Random();
                    int f1 = rand.nextInt(theFolks.size());
                    int f2 = f1;
                    while (f2 == f1) {
                        f2 = rand.nextInt(theFolks.size());
                    }

                    FolkData folk1 = (FolkData) theFolks.get(f1);
                    FolkData folk2 = (FolkData) theFolks.get(f2);
                    Relationship.meddleWithRelationship(folk1, folk2);
                }
                for (FolkData folk : theFolks) {
                    folk.destination = null;
                    if (folk.theEntity != null) {
                        folk.theEntity.func_70661_as().func_75499_g();
                    }
                }
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("dayTransitionHandler出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }


    }

    /**
     * npc 年龄增长
     */
    private static void evolveFolks() {
        try {
            if (theFolks.size() > 0) {
                Random rand = new Random();
                //evolving folks
                ModSimReloaded.log.info("进化的人");
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(3000L);
                        } catch (Exception e) {
                        }
                        //总租金
                        float totalRent = 0.0F;
                        //总税务
                        float totalCorpTax = 0.0F;
                        //如果游戏模式不是创造模式
                        if (GameMode.gameMode != GameMode.GAMEMODES.CREATIVE) {
                            //循环所有的建筑
                            for (int b = 0; b < ModSimReloaded.theBuildings.size(); b++) {
                                //获得建筑
                                Building building = (Building) ModSimReloaded.theBuildings.get(b);
                                //如果建筑是住宅并且 住宅租户大于0/有租户
                                if (building.type.contentEquals("residential") && building.tenants.size() > 0) {
                                    //建筑的租金是空或者0
                                    if (building.rent == null || building.rent == 0.0F) {
                                        //租金赋值为1
                                        building.rent = 1f;
                                    }

                                    ModSimReloaded.log.info("房屋租金 " + building.displayNameWithoutPK + ": " + building.rent + "(" + building.blocksInBuilding + ")");
                                    //租金叠加
                                    totalRent += building.rent;
                                }
                                if (building.type.contentEquals("commercial") && FolkData.getFolkByEmployedAt(building.primaryXYZ) != null) {
                                    if (building.rent == null || building.rent == 0f) {
                                        building.rent = 1f;
                                    }

                                    ModSimReloaded.log.info("建筑公司税 " + building.displayNameWithoutPK + ": " + building.rent + "(" + building.blocksInBuilding + ")");
                                    totalCorpTax += building.rent;
                                }
                            }
                        }
                        //如果租金大于0
                        if (totalRent > 0.0F) {
                            //今天收了 金的房租。
                            sendChat(I18n.func_135052_a("container.sim.main_Collected") + ModSimReloaded.displayMoney(totalRent) + I18n.func_135052_a("container.sim.main_rent_today"));
                            //今天收了 金的税收。
                            sendChat(I18n.func_135052_a("container.sim.main_Collected") + ModSimReloaded.displayMoney(totalCorpTax) + I18n.func_135052_a("container.sim.main_tax_today"));
                            //游戏状态
                            GameStates var10000 = ModSimReloaded.states;
                            //金币
                            var10000.credits += totalRent;
                            //税收
                            var10000.credits += totalCorpTax;
                            EntityPlayer p = Minecraft.func_71410_x().field_71439_g;
                            if (p != null) {
                                ModSim.proxy.getClientWorld().func_72980_b(p.field_70165_t, p.field_70163_u, p.field_70161_v, ModSim.MODID + ":cash", 1, 1, false);
                            }
                        } else if (GameMode.gameMode != GameMode.GAMEMODES.CREATIVE) {
                            //今天没有收到房租,你应该雇一个人来盖一栋住宅。
                            sendChat(I18n.func_135052_a("container.sim.main_No_rent"));
                        }

                    }
                });
                //启动线程
                t.start();

                for (int i = 0; i < theFolks.size(); i++) {
                    //获取npc
                    FolkData folk = (FolkData) theFolks.get(i);
                    //重置今天打招呼为否
                    folk.greetedToday = false;
                    //交配为负
                    folk.shaggingStage = -1;
                    //如果怀孕则加一
                    if (folk.pregnancyStage > 0.0F) {
                        //增加怀孕-出生在FolkData中
                        folk.pregnancyStage += 0.1F;
                    }
                    //年龄
                    int age = folk.age;
                    //年龄大于18则
                    if (age >= 18) {
                        //如果星期六 大一岁
                        if (states.dayOfWeek == 6) {
                            //周六上午
                            folk.age++;
                        }
                        //小于18 则周三或者周六 年龄加一
                    } else {
                        if (states.dayOfWeek == 3 || states.dayOfWeek == 6) {
                            //让孩子一周两次上年纪
                            folk.age++;
                            if (age == 17 && folk.age == 18) {
                                //现在是成年人了（皮肤会自动变化）
                                //被赶出家 不在父母家
                                folk.evictThem();
                                //现在18岁了,他们会开始找房子,你现在也可以雇佣他们了。
                                sendChat(folk.name + I18n.func_135052_a("container.sim.main_is_now"));
                            }
                        }
                    }
                    //年龄大于110 当他们超过110时杀死他们（随机1/10）
                    if (folk.age > 110 && rand.nextInt(10) == 5) {
                        //年纪大了,感觉不太好。。。哦不！
                        sendChat(folk.name + I18n.func_135052_a("container.sim.main_is_old"));
                        //npc老死
                        folk.eventDied(DamageSource.field_76377_j);
                    }
                }
                //不是创造模式
                if (GameMode.gameMode != GameMode.GAMEMODES.CREATIVE) {
                    //随机数 每个比赛周让他们老化一年
                    int fl = rand.nextInt(theFolks.size());
                    //循环所有
                    for (int f = 0; f < theFolks.size(); ++f) {
                        FolkData folk = (FolkData) theFolks.get(f);
                        if (f == fl) {
                            //饥饿等级
                            folk.levelFood--;
                            if (folk.levelFood == 0) {
                                //非常饿,你应该建一个农场、杂货店、面包店或向他们扔一些食物。
                                sendChat(folk.name + I18n.func_135052_a("container.sim.main_is_VERY"));
                            } else if (folk.levelFood < 0) {
                                //饥饿等级小于-开始掉血
                            }
                        }
                        //付钱给士兵

                        if (folk.theirJob != null && folk.vocation == Vocation.SOLDIER) {
                            JobSoldier job = (JobSoldier) folk.theirJob;
                            //酬金
                            float pay = (float) job.kills * 0.2F;
                            if (job.kills > 0) {
                                //支付了 npc 酬金,昨天杀了 0 敌对暴徒。
                                sendChat(I18n.func_135052_a("container.sim.main_Paid1") + folk.name + " " + displayMoney(pay) + I18n.func_135052_a("container.sim.main_Paid2") + job.kills + I18n.func_135052_a("container.sim.main_Paid3"));
                                GameStates var10000 = states;
                                var10000.credits -= pay;
                                job.kills = 0;
                            }
                        }
                    }
                    //大宗价格波动（建筑商-商户）
                    boolean updown = rand.nextBoolean();
                    //木板的价格
                    PricesForBlocks.adjustPrice(Blocks.field_150344_f, updown);
                    updown = rand.nextBoolean();
                    //圆石的价格
                    PricesForBlocks.adjustPrice(Blocks.field_150347_e, updown);
                    updown = rand.nextBoolean();
                    //石头的价格
                    PricesForBlocks.adjustPrice(Blocks.field_150348_b, updown);
                    updown = rand.nextBoolean();
                    //玻璃的价格
                    PricesForBlocks.adjustPrice(Blocks.field_150359_w, updown);
                    updown = rand.nextBoolean();
                    //羊毛的价格
                    PricesForBlocks.adjustPrice(Blocks.field_150325_L, updown);
                    updown = rand.nextBoolean();
                    //砖块的价格
                    PricesForBlocks.adjustPrice(Blocks.field_150336_V, updown);
                    updown = rand.nextBoolean();
                    //石砖的价格
                    PricesForBlocks.adjustPrice(Blocks.field_150417_aV, updown);
                    updown = rand.nextBoolean();
                    //栅栏的价格
                    PricesForBlocks.adjustPrice(Blocks.field_180407_aO, updown);
                }
                //游戏状态保存
                states.saveStates();
                //刷新可用商品
                Commodity.refreshAvailableCommoditities();
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("evolveFolks出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }

    }

    //拆除
    public static void demolishBlocks() {
        try {
            if (demolishBlocks.size() >= 1) {
                int count = demolishBlocks.size();
                if (count > 10) {
                    count = 10;
                }

                for (int i = 0; i < count; i++) {
                    V3 blockLoc = (V3) demolishBlocks.get(0);

                    try {
                        Block block = Block.func_149684_b(blockLoc.name);
                        BlockPos blockPos = new BlockPos(blockLoc.field_72450_a, blockLoc.field_72448_b + 10 + (new Random()).nextInt(20), blockLoc.field_72449_c);
                        block.func_176226_b(demolishWorld, blockPos, block.func_176223_P(), 0);
                        demolishBlocks.remove(0);
                    } catch (Exception e) {
                    }
                }

            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("demolishBlocks出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
    }

    /**
     * 升级农场
     * 从commonTickHandler（）每次勾选调用，以将场从一个级别升级到下一个级别
     */
    public static void upgradeFarm() {
        try {

            //如果农场等级为0 则1
            if (farmToUpgrade.level == 0) {
                farmToUpgrade.level = 1;
            }

            V3 point;
            WorldServer theWorld;
            //升级至2级（围栏和灯光）
            if (farmToUpgrade.level == 1) {
                //如果农场为空则重新获取
                if (farmToUpgradePoints == null) {
                    farmToUpgradePoints = farmToUpgrade.getPerimeterPoints();
                }
                //获取元素
                point = (V3) farmToUpgradePoints.get(farmToUpgradeCounter);
                theWorld = MinecraftServer.func_71276_C().func_71218_a(point.theDimension);
                BlockPos blockPos = new BlockPos(point.field_72450_a, point.field_72448_b, point.field_72449_c);
                //如果该区域没有障碍物，则设置围栏
                Block id = theWorld.func_180495_p(blockPos).func_177230_c();
                //摧毁
                boolean destroy = false;
                //方块不为空
                if (id != null) {
                    //获取实体
                    TileEntity te = theWorld.func_175625_s(blockPos);
                    if (te == null) {
                        destroy = true;
                    } else if (!(te instanceof IInventory)) {
                        destroy = true;
                    }
                } else {
                    destroy = true;
                }

                if (destroy) {
                    //System.out.println("farmToUpgradeCounter:" + farmToUpgradeCounter);
                    BlockPos blockPos2 = new BlockPos(point.field_72450_a - 1, point.field_72448_b, point.field_72449_c - 1);
                    //摧毁放快
                    theWorld.func_175655_b(blockPos2, true);
                    //把原来方块替换成 栅栏
                    theWorld.func_180501_a(blockPos2, Blocks.field_180407_aO.func_176223_P(), 3);
                    //更新方块标记
                    theWorld.func_175689_h(blockPos2);
                }
                //升级点除以六等于0 每隔6个街区放置一盏灯
                if (farmToUpgradeCounter % 6 == 0) {
                    BlockPos blockPos1 = new BlockPos(point.field_72450_a - 1, point.field_72448_b - 1, point.field_72449_c - 1);
                    theWorld.func_175655_b(blockPos1, true);
                    //把原来方块替换成 灯箱
                    theWorld.func_180501_a(blockPos1, BlockLoader.blockLightBox.func_176223_P(), 3);
                    theWorld.func_175689_h(blockPos1);
                }
                // 升级至3级（灌溉）
            } else if (farmToUpgrade.level == 2) {
                //如果农场为空则重新获取
                if (farmToUpgradePoints == null) {
                    farmToUpgradePoints = farmToUpgrade.getSoilBlockPoints();
                }

                point = (V3) farmToUpgradePoints.get(farmToUpgradeCounter);
                theWorld = MinecraftServer.func_71276_C().func_71218_a(point.theDimension);
                if (point.field_72450_a % 5 == 0 && point.field_72449_c % 5 == 0) {

                    BlockPos blockPos1 = new BlockPos(point.field_72450_a, point.field_72448_b - 1, point.field_72449_c);
                    theWorld.func_180501_a(blockPos1, Blocks.field_150355_j.func_176223_P(), 3);

                    BlockPos blockPos2 = new BlockPos(point.field_72450_a, point.field_72448_b - 2, point.field_72449_c);
                    theWorld.func_180501_a(blockPos2, BlockLoader.blockLightBox.func_176223_P(), 3);
                    theWorld.func_175689_h(blockPos1);
                    theWorld.func_175689_h(blockPos2);
                }
            }

            farmToUpgradeCounter++;

            if (farmToUpgradeCounter > farmToUpgradePoints.size() - 1) {
                farmToUpgrade.level++;
                farmToUpgradePoints = null;
                farmToUpgrade = null;
                farmToUpgradeCounter = 0;
                ModSimReloaded.log.info("完成农场升级");
            }
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("升级农场出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
    }

    public static String getDayOfWeek() {
        String[] dow = null;
        try {
            String simSun = I18n.func_135052_a("container.sim.simSun");
            String simMon = I18n.func_135052_a("container.sim.simMon");
            String simTue = I18n.func_135052_a("container.sim.simTue");
            String simWed = I18n.func_135052_a("container.sim.simWed");
            String simThu = I18n.func_135052_a("container.sim.simThu");
            String simFri = I18n.func_135052_a("container.sim.simFri");
            String simSat = I18n.func_135052_a("container.sim.simSat");
            dow = new String[]{simSun, simMon, simTue, simWed, simThu, simFri, simSat};
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("getDayOfWeek出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }
        return dow[states.dayOfWeek];
    }

    public static List<String> loadSK2(String fullFilename) {
        CopyOnWriteArrayList ret = new CopyOnWriteArrayList();

        try {
            BufferedReader br = new BufferedReader(new FileReader(fullFilename));

            for (String line = br.readLine(); line != null; line = br.readLine()) {
                ret.add(line);
            }

            br.close();
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("loadSK2出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
        }

        return ret;
    }

    public static void saveSK2(String fullFilename, List<String> strings) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fullFilename));
            Iterator iterator = strings.iterator();

            while (iterator.hasNext()) {
                String line = (String) iterator.next();
                bw.write(line + "\r\n");
            }

            bw.close();
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.error("saveSK2出错了：" + e.getMessage() + "行数：" + element.getLineNumber());
            //var5.printStackTrace();
        }

    }

    /**
     * 保存对象
     *
     * @param filename
     * @param o
     */
    public void saveObject(String filename, Object o) {
    }

    /**
     * 加载对象
     *
     * @param filename
     * @return
     */
    public static Object loadObject(String filename) {
        Object o = null;

        try {
            FileInputStream fis2 = new FileInputStream(filename);
            ObjectInputStream in2 = new ObjectInputStream(fis2);
            o = in2.readObject();
            in2.close();
        } catch (Exception e) {
            StackTraceElement element = e.getStackTrace()[0];
            ModSimReloaded.log.info("旧加载程序-无法加载对象 " + e.getMessage() + "行数：" + element.getLineNumber());
        }

        return o;
    }
}

package com.trhsy.sim.client.entity.model;

import com.trhsy.sim.common.loader.ModSimReloaded;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelWindmill extends ModelBase {
    public ModelRenderer Vane1rod;
    public ModelRenderer Vane2rod;
    public ModelRenderer Vane3rod;
    public ModelRenderer Vane4rod;
    public ModelRenderer Vane1main;
    public ModelRenderer Vane2main;
    public ModelRenderer Vane3main;
    public ModelRenderer Vane4main;
    public ModelRenderer WindmillAxle;
    ModelRenderer WindmillTop;
    ModelRenderer WindmillMid;
    ModelRenderer WindmillBase;
    public String renderTexture;

    public ModelWindmill() {
        try {
            renderTexture = "/mods/sim/textures/models/entityWindmill.png";
            field_78090_t = 512;
            field_78089_u = 512;

            Vane1rod = new ModelRenderer(this, 200, 500);
            Vane1rod.func_78789_a(-96F, -1F, -1F, 96, 2, 2);
            Vane1rod.func_78793_a(0F, -105F, -43F);
            Vane1rod.func_78787_b(512, 512);
            Vane1rod.field_78809_i = true;
            setRotation(Vane1rod, 0F, 0F, 0F);
            Vane2rod = new ModelRenderer(this, 200, 500);
            Vane2rod.func_78789_a(-96F, -1F, -1F, 96, 2, 2);
            Vane2rod.func_78793_a(0F, -105F, -43F);
            Vane2rod.func_78787_b(512, 512);
            Vane2rod.field_78809_i = true;
            setRotation(Vane2rod, 0F, 0F, 1.570796F);
            Vane3rod = new ModelRenderer(this, 200, 500);
            Vane3rod.func_78789_a(-96F, -1F, -1F, 96, 2, 2);
            Vane3rod.func_78793_a(0F, -105F, -43F);
            Vane3rod.func_78787_b(512, 512);
            Vane3rod.field_78809_i = true;
            setRotation(Vane3rod, 0F, 0F, 3.141593F);
            Vane4rod = new ModelRenderer(this, 200, 500);
            Vane4rod.func_78789_a(-96F, -1F, -1F, 96, 2, 2);
            Vane4rod.func_78793_a(0F, -105F, -43F);
            Vane4rod.func_78787_b(512, 512);
            Vane4rod.field_78809_i = true;
            setRotation(Vane4rod, 0F, 0F, -1.570796F);
            Vane1main = new ModelRenderer(this, 0, 490);
            Vane1main.func_78789_a(-95F, -20F, -1F, 93, 19, 1);
            Vane1main.func_78793_a(0F, -105F, -43F);
            Vane1main.func_78787_b(512, 512);
            Vane1main.field_78809_i = true;
            setRotation(Vane1main, 0.0872665F, 0F, 0F);
            Vane2main = new ModelRenderer(this, 0, 490);
            Vane2main.func_78789_a(-95F, -20F, -1F, 93, 19, 1);
            Vane2main.func_78793_a(0F, -105F, -43F);
            Vane2main.func_78787_b(512, 512);
            Vane2main.field_78809_i = true;
            setRotation(Vane2main, 0.0872665F, 0F, 1.570796F);
            Vane3main = new ModelRenderer(this, 0, 490);
            Vane3main.func_78789_a(-95F, -20F, -1F, 93, 19, 1);
            Vane3main.func_78793_a(0F, -105F, -43F);
            Vane3main.func_78787_b(512, 512);
            Vane3main.field_78809_i = true;
            setRotation(Vane3main, 0.0872665F, 0F, 3.141593F);
            Vane4main = new ModelRenderer(this, 0, 490);
            Vane4main.func_78789_a(-95F, -20F, -1F, 93, 19, 1);
            Vane4main.func_78793_a(0F, -105F, -43F);
            Vane4main.func_78787_b(512, 512);
            Vane4main.field_78809_i = true;
            setRotation(Vane4main, 0.0872665F, 0F, -1.570796F);
            WindmillAxle = new ModelRenderer(this, 0, 400);
            WindmillAxle.func_78789_a(-8F, -8F, -1F, 16, 16, 26);
            WindmillAxle.func_78793_a(0F, -105F, -41F);
            WindmillAxle.func_78787_b(512, 512);
            WindmillAxle.field_78809_i = true;
            setRotation(WindmillAxle, 0F, 0F, 0F);
            WindmillTop = new ModelRenderer(this, 0, 300);
            WindmillTop.func_78789_a(-16F, 0F, -16F, 32, 32, 32);
            WindmillTop.func_78793_a(0F, -120F, 0F);
            WindmillTop.func_78787_b(512, 512);
            WindmillTop.field_78809_i = true;
            setRotation(WindmillTop, 0F, 0F, 0F);
            WindmillMid = new ModelRenderer(this, 0, 140);
            WindmillMid.func_78789_a(-32F, 0F, -32F, 64, 64, 64);
            WindmillMid.func_78793_a(0F, -88F, 0F);
            WindmillMid.func_78787_b(512, 512);
            WindmillMid.field_78809_i = true;
            setRotation(WindmillMid, 0F, 0F, 0F);
            WindmillBase = new ModelRenderer(this, 0, 0);
            WindmillBase.func_78789_a(-40F, 0F, -40F, 80, 48, 80);
            WindmillBase.func_78793_a(0F, -24.06667F, 0F);
            WindmillBase.func_78787_b(512, 512);
            WindmillBase.field_78809_i = true;
            setRotation(WindmillBase, 0F, 0F, 0F);
        } catch (Exception e) {
            ModSimReloaded.log.error("初始化风车出错了：" + e.getMessage());
        }

    }

    @Override
    public void func_78088_a(Entity par1Entity, float par2, float par3, float par4,
                       float par5, float par6, float par7) {
        try {
            Vane1rod.func_78785_a(1.0f);
            Vane2rod.func_78785_a(1.0f);
            Vane3rod.func_78785_a(1.0f);
            Vane4rod.func_78785_a(1.0f);
            Vane1main.func_78785_a(1.0f);
            Vane2main.func_78785_a(1.0f);
            Vane3main.func_78785_a(1.0f);
            Vane4main.func_78785_a(1.0f);
            WindmillAxle.func_78785_a(1.0f);
            WindmillTop.func_78785_a(1.0f);
            WindmillMid.func_78785_a(1.0f);
            WindmillBase.func_78785_a(1.0f);
            super.func_78088_a(par1Entity, par2, par3, par4, par5, par6, par7);
        } catch (Exception e) {
            ModSimReloaded.log.error("初始化风车出错了：" + e.getMessage());
        }
    }

    private void setRotation(ModelRenderer model, float x, float y, float z) {
        try {
            model.field_78795_f = x;
            model.field_78796_g = y;
            model.field_78808_h = z;
        } catch (Exception e) {
            ModSimReloaded.log.error("初始化风车出错了：" + e.getMessage());
        }

    }


}

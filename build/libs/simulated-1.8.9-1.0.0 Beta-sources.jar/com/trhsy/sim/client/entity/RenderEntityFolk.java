package com.trhsy.sim.client.entity;

import com.trhsy.sim.ModSim;
import com.trhsy.sim.client.entity.model.ModelFolkFemale;
import com.trhsy.sim.common.entity.EntityFolk;
import com.trhsy.sim.common.loader.ModSimReloaded;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

/**
 * @ClassName RenderEntityFolk
 * @Description todo 男性NPC
 * @Author Tian
 * @Date 2022/5/2216:56
 **/
@SideOnly(Side.CLIENT)
public class RenderEntityFolk extends RenderBiped<EntityFolk> {
    public RenderEntityFolk(RenderManager renderManager) {
        /**
         * @Author fan
         * @Description //TODO
         * Minecraft的渲染管理器
         * 实体生物的实体渲染模型
         * @Date 17:44 2022/5/22
         * @Param [renderManager]
         * @return
         **/
        super(renderManager, new ModelFolkFemale(), 0.5F);
    }


    @Override
    protected ResourceLocation func_110775_a(EntityFolk entity) {
        if (entity instanceof EntityFolk) {
            EntityFolk theFolk = (EntityFolk) entity;
            ResourceLocation myTexture = new ResourceLocation(ModSim.MODID, "skins/" + theFolk.getTexture());
            return myTexture;
        } else {
            return null;
        }
    }

    /**
     * 预渲染回调
     *
     * @param entity
     * @return
     */
    @Override
    protected void func_77041_b(EntityFolk entity, float partialTickTime) {
        try {
            GlStateManager.func_179152_a(1F, 1F, 1F);
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("渲染npc出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }

    }

    @Override
    public void func_76986_a(EntityFolk par1Entity, double par2, double par4, double par6, float par8, float par9) {
        try {
            super.func_76986_a(par1Entity, par2, par4, par6, par8, par9);
            this.doRenderFolk((EntityFolk) par1Entity, par2, par4, par6, par8, par9);
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("渲染npc出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }

    }

    public void doRenderLiving(EntityLiving entityliving, double d, double d1, double d2, float f, float f1) {
        try {
            double d3 = d1 - (double) entityliving.func_70033_W();
            this.doRenderLiving(entityliving, d, d3, d2, f, f1);
            this.doRenderFolk((EntityFolk) entityliving, d, d3, d2, f, f1);
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("渲染npc出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }
    }

    /**
     * 渲染npc
     *
     * @param entityFolk
     * @param d
     * @param d1
     * @param d2
     * @param f
     * @param f1
     */
    private void doRenderFolk(EntityFolk entityFolk, double d, double d1, double d2, float f, float f1) {
        try {
            float f2 = 1.6F;
            float f3 = 0.01666667F * f2;
            float f6 = 0.2F;
            if (entityFolk.theData != null && entityFolk != null) {
                double dist = (double) entityFolk.func_70032_d(Minecraft.func_71410_x().field_71439_g);
                if (dist < 40) {
                    if (entityFolk.theData.age < 18) {
                        this.displayText(entityFolk.theData.name + " (" + entityFolk.theData.age + ")", 0.03F, -1, (float) d, (float) d1 + f3 + f6 - 0.4F, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.statusText, 0.02F, -256, (float) d, (float) d1 + f3 + f6 - 0.7F, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.status4, 0.02F, -256, (float) d, (float) d1 + f3 + f6 - 1.0F, (float) d2, entityFolk);
                    } else if (dist >= 4) {
                        this.displayText(entityFolk.theData.name + " (" + entityFolk.theData.age + ")", 0.03F, -1, (float) d, (float) d1 + f3 + f6, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.statusText, 0.02F, -256, (float) d, (float) d1 + f3 + f6 - 0.3F, (float) d2, entityFolk);
                    } else {
                        this.displayText(entityFolk.theData.name + " (" + entityFolk.theData.age + ")", 0.03F, -1, (float) d, (float) d1 + f3 + f6 + 1.5F, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.statusText, 0.02F, -256, (float) d, (float) d1 + f3 + f6 + 1.2F, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.status1, 0.02F, -256, (float) d, (float) d1 + f3 + f6 + 0.9F, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.status2, 0.02F, -256, (float) d, (float) d1 + f3 + f6 + 0.6F, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.status3, 0.02F, -256, (float) d, (float) d1 + f3 + f6 + 0.3F, (float) d2, entityFolk);
                        this.displayText(entityFolk.theData.status4, 0.02F, -256, (float) d, (float) d1 + f3 + f6 + 0.0F, (float) d2, entityFolk);
                    }
                }
            }
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("初始化对齐梁出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }
    }

    /**
     * 显示文字
     *
     * @param s
     * @param f
     * @param i
     * @param f1
     * @param f2
     * @param f3
     * @param entitybuilder
     */
    private void displayText(String s, float f, int i, float f1, float f2, float f3, EntityFolk entitybuilder) {
        try {
            FontRenderer fontrenderer = this.func_76983_a();
            GL11.glPushMatrix();
            GL11.glTranslatef(f1, f2 + 2.3F, f3);
            GL11.glNormal3f(0.0F, 1.0F, 0.0F);
            GL11.glRotatef(-this.field_76990_c.field_78735_i, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(this.field_76990_c.field_78732_j, 1.0F, 0.0F, 0.0F);
            GL11.glScalef(-f, -f, f);
            GL11.glDisable(2896);
            GL11.glDepthMask(false);
            GL11.glDisable(2929);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            Tessellator tessellator = Tessellator.func_178181_a();
            GL11.glDisable(3553);
            tessellator.func_178180_c().func_181668_a(7, tessellator.func_178180_c().func_178973_g());
            int j = fontrenderer.func_78256_a(s) / 2;
            tessellator.func_178180_c().func_178994_b(0.0F, 0.0F, 0.0F, 0);
            tessellator.func_178180_c().func_181674_a((float) (-j - 1), -1, 0);
            tessellator.func_178180_c().func_181674_a((float) (-j - 1), 8, 0);
            tessellator.func_178180_c().func_181674_a((float) (j + 1), 8, 0);
            tessellator.func_178180_c().func_181674_a((float) (j + 1), -1, 0);
            tessellator.func_78381_a();
            GL11.glEnable(3553);
            fontrenderer.func_78276_b(s, -fontrenderer.func_78256_a(s) / 2, 0, i);
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            fontrenderer.func_78276_b(s, -fontrenderer.func_78256_a(s) / 2, 0, i);
            GL11.glEnable(2896);
            GL11.glDisable(3042);
            GL11.glPopMatrix();
        } catch (Exception e) {
            StackTraceElement element=e.getStackTrace()[0];ModSimReloaded.log.error("初始化对齐梁出错了：" + e.getMessage()+"行数："+element.getLineNumber());
        }

    }
}
